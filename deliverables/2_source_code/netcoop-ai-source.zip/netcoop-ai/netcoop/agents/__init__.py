"""netcoop.agents package."""
