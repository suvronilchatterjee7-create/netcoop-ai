"""netcoop.correlation package."""
