"""netcoop.courtroom package."""
