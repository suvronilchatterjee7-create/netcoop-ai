"""netcoop.cli package."""
