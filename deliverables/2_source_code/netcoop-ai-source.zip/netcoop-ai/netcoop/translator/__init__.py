"""netcoop.translator package."""
