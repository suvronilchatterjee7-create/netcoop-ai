"""netcoop.protocol package."""
