"""netcoop.board package."""
